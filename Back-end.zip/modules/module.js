const fullName = (first, last) => {
  return `${first} ${last}`;
};

const sum = (a, b) => {
  return a + b;
};

module.exports = { fullName, sum };
