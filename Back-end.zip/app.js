const { fullNames, sum } = require("./modules/module");

console.log(fullNames("watna", "panha"));
console.log(sum(5, 7));
